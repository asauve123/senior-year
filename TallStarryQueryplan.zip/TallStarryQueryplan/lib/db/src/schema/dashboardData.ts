import { createInsertSchema } from "drizzle-zod";
import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod";

export const dashboardDataTable = pgTable("dashboard_data", {
  userId: text("user_id").primaryKey(),
  data: jsonb("data").$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertDashboardDataSchema = createInsertSchema(
  dashboardDataTable,
).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertDashboardData = z.infer<typeof insertDashboardDataSchema>;
export type DashboardData = typeof dashboardDataTable.$inferSelect;