import { getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, dashboardDataTable } from "@workspace/db";
import {
  DashboardResponse,
  SaveDashboardBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/dashboard", async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const [record] = await db
    .select()
    .from(dashboardDataTable)
    .where(eq(dashboardDataTable.userId, userId));

  res.json(DashboardResponse.parse({ data: record?.data ?? {} }));
});

router.put("/dashboard", async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const parsed = SaveDashboardBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [record] = await db
    .insert(dashboardDataTable)
    .values({ userId, data: parsed.data.data })
    .onConflictDoUpdate({
      target: dashboardDataTable.userId,
      set: { data: parsed.data.data, updatedAt: new Date() },
    })
    .returning();

  res.json(DashboardResponse.parse({ data: record.data }));
});

export default router;